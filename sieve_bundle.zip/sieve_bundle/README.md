# Golden-ratio sieve bundle

The sieve: channel(n) = floor(3 * frac(n * phi)), phi = golden ratio.

Run any file with `python name.py`; each has `--test` (prints "all N checks passed").

| file | what it does |
|---|---|
| sieve_lab.py | audit of the original sieve (keeps 1/5, aliases) vs the fixed one (true 1/3) |
| sieve_experiments.py | sieve vs stride / random / stratified sampling, hybrid floor test, float precision |
| sieve_explore.py | uses: 2-D spiral map, sphere points, integration, buckets, dithering, spectrum, `--plot` |
| sieve_patterns.py | the sieve as a pattern dial (rational = loop, irrational = never repeats), `--plot` |
| pattern_engine.py | create / recognise / predict / flag patterns; families rotation, loop, fibword; `--demo --bench --plot` |

Needs numpy; sieve_explore.py also scipy; plots need matplotlib. Output files and pictures are included.
