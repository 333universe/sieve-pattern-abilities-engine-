# NPKmath Custom Framework
This customized framework allows you to provide custom question files (`custom_data.json`) 
directly in your runtime folder. The framework parses them natively into the evaluation pipeline 
without requiring any custom changes to your Jupyter Notebook cells.
