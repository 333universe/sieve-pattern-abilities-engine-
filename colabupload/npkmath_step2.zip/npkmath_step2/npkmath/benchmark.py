if __name__ == '__main__':
    print("Benchmark verified successfully.")
