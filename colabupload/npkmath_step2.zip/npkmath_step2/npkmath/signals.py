class AIFeedbackInterface:
    def __init__(self):
        self.feedback_log = []
