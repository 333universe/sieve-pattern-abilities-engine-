class NPKCoreEngine:
    def __init__(self):
        pass
