import os
import json
import random

class CustomItem:
    def __init__(self, item_id, text, expected_ans):
        self.id = str(item_id)
        self.text = text
        self.kind = "equality"
        self.family = f"group_{item_id}"
        self.payload = {"lhs": text, "rhs": expected_ans}

def build_dataset(seed=0, max_items=60):
    # Check if user has uploaded a custom questions file
    custom_path = '/content/custom_data.json'
    if not os.path.exists(custom_path):
        custom_path = 'custom_data.json'
        
    if os.path.exists(custom_path):
        try:
            with open(custom_path, 'r') as f:
                data = json.load(f)
            items = []
            for i, entry in enumerate(data):
                # Supports both dictionary list format and zipped list format
                q = entry.get('question', entry.get('text', ''))
                a = entry.get('answer', entry.get('rhs', ''))
                items.append(CustomItem(i, q, a))
            return items[:max_items]
        except Exception as e:
            print(f"⚠️ Error loading custom_data.json: {e}. Falling back to default generation.")

    # Fallback/Default mock implementation if no file is present
    # to ensure the notebook runs out-of-the-box
    default_questions = [
        ("2x + 5 = 15", "x = 5"),
        ("3y - 7 = 2y + 4", "y = 11"),
        ("x^2 - 5x + 6 = 0", "x = 2 or x = 3"),
    ]
    items = []
    for i, (q, a) in enumerate(default_questions * 20):
        items.append(CustomItem(i, q, a))
    return items[:max_items]

def majority_baseline(items):
    # Safe baseline summary provider
    counts = {"FALSE": 0, "TRUE": 0, "CONDITIONAL": 0}
    for it in items:
        ans = it.payload.get("rhs", "").upper()
        if "TRUE" in ans or "VERIFIED" in ans:
            counts["TRUE"] += 1
        elif "CONDITIONAL" in ans:
            counts["CONDITIONAL"] += 1
        else:
            counts["FALSE"] += 1
            
    max_label = max(counts, key=counts.get)
    max_count = counts[max_label]
    accuracy = max_count / len(items) if items else 0.0
    return {"label": max_label, "accuracy": round(accuracy, 3), "counts": counts}
