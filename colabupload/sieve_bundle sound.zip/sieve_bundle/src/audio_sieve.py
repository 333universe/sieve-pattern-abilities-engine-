import math
import struct
import os

class AudioSieveSequencer:
    def __init__(self, sample_rate=44100):
        self.sample_rate = sample_rate
        self.phi = (math.sqrt(5) - 1) / 2

    def generate_sine_wave(self, frequency, duration_ms, amplitude=0.3):
        total_samples = int((duration_ms / 1000.0) * self.sample_rate)
        wave = []
        for i in range(total_samples):
            t = i / self.sample_rate
            value = amplitude * math.sin(2 * math.pi * frequency * t)
            wave.append(value)
        return wave

    def build_sieve_sequence(self, total_steps=64, bpm=120):
        step_duration_ms = int((60000 / bpm) / 4)
        final_audio_stream = []
        voice_frequencies = [110.0, 220.0, 440.0]

        for step in range(total_steps):
            step_samples = int((step_duration_ms / 1000.0) * self.sample_rate)
            mixed_step_buffer = [0.0] * step_samples

            for voice_idx in range(3):
                dial = (step * (self.phi * (voice_idx + 1))) % 1.0
                trigger_threshold = 1.0 / (voice_idx + 3)

                if dial < trigger_threshold:
                    tone = self.generate_sine_wave(voice_frequencies[voice_idx], step_duration_ms, amplitude=0.2)
                    for i in range(min(len(mixed_step_buffer), len(tone))):
                        mixed_step_buffer[i] += tone[i]

            final_audio_stream.extend(mixed_step_buffer)
        return final_audio_stream

    def save_wav_file(self, audio_data, output_filename="outputs/visuals/sieve_composition.wav"):
        os.makedirs(os.path.dirname(output_filename), exist_ok=True)
        binary_frames = bytearray()
        for sample in audio_data:
            sample = max(-1.0, min(1.0, sample))
            integer_sample = int(sample * 32767)
            binary_frames.extend(struct.pack("<h", integer_sample))

        num_channels = 1
        bytes_per_sample = 2
        subchunk2_size = len(binary_frames)
        chunk_size = 36 + subchunk2_size
        byte_rate = self.sample_rate * num_channels * bytes_per_sample
        block_align = num_channels * bytes_per_sample

        header = struct.pack(
            "<4sI4s4sIHHIIHH4sI",
            b"RIFF", chunk_size, b"WAVE", b"fmt ", 16, 1,
            num_channels, self.sample_rate, byte_rate, block_align, 16, b"data", subchunk2_size
        )

        with open(output_filename, "wb") as wav_file:
            wav_file.write(header)
            wav_file.write(binary_frames)
